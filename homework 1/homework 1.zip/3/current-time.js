// JavaScript source code
var currentDate = new Date();
var output = currentDate.getHours() + ":" + currentDate.getMinutes();
console.log(output);

